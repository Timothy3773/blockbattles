/*
var page = document
addEventListener("keypress", input => {
    if (input.shiftKey && input.key == "G"){
        if (page.body.classList.contains("has-background-grey-dark")){
            for (i = 0; i < page.body.getElementsByClassName("has-text-white-bis").length; i++){
                page.body.getElementsByClassName("has-text-white-bis").item(i).classList.replace("has-text-white-bis", "has-text-dark")
            }
            page.body.classList.replace("has-background-grey-dark", "has-background-white")
        } else if (page.body.classList.contains("has-background-white")){
            page.body.classList.replace("has-background-white", "has-background-grey-dark")
            for (i = 0; i < page.body.getElementsByClassName("has-text-black").length; i++) {
                page.body.getElementsByClassName("has-text-black").item(i).classList.replace("has-text-black", "has-text-white-bis")
            }
        }
    }
})
*/

